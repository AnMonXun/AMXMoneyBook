#!/bin/bash
# 启动记账本本地服务
cd "$(dirname "$0")" || exit 1

PORT=8848
IP=$(ipconfig getifaddr en0 2>/dev/null || ipconfig getifaddr en1 2>/dev/null || echo "")

echo ""
echo "  记账本已启动"
echo "  电脑访问： http://localhost:$PORT"
if [ -n "$IP" ]; then
  echo "  手机访问： http://$IP:$PORT   （需与电脑连同一个 Wi-Fi）"
fi
echo "  按 Ctrl+C 停止"
echo ""

python3 -m http.server "$PORT"
