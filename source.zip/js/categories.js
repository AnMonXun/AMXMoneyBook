export const CATEGORIES = [
  { id: 'food', name: '餐饮', icon: '🍜', color: '#F97066', type: 'expense' },
  { id: 'traffic', name: '交通', icon: '🚌', color: '#FDB022', type: 'expense' },
  { id: 'shopping', name: '购物', icon: '🛍️', color: '#EE46BC', type: 'expense' },
  { id: 'home', name: '居住', icon: '🏠', color: '#7A5AF8', type: 'expense' },
  { id: 'fun', name: '娱乐', icon: '🎬', color: '#2E90FA', type: 'expense' },
  { id: 'health', name: '医疗', icon: '💊', color: '#12B76A', type: 'expense' },
  { id: 'study', name: '学习', icon: '📚', color: '#06AED4', type: 'expense' },
  { id: 'comm', name: '通讯', icon: '📱', color: '#667085', type: 'expense' },
  { id: 'gift', name: '人情', icon: '🎁', color: '#F04438', type: 'expense' },
  { id: 'daily', name: '日用', icon: '🧴', color: '#0BA5EC', type: 'expense' },
  { id: 'travel', name: '旅行', icon: '✈️', color: '#66C61C', type: 'expense' },
  { id: 'other-e', name: '其他', icon: '📦', color: '#98A2B3', type: 'expense' },

  { id: 'salary', name: '工资', icon: '💼', color: '#12B76A', type: 'income' },
  { id: 'bonus', name: '奖金', icon: '🎉', color: '#FDB022', type: 'income' },
  { id: 'invest', name: '理财', icon: '📈', color: '#2E90FA', type: 'income' },
  { id: 'parttime', name: '兼职', icon: '🧾', color: '#7A5AF8', type: 'income' },
  { id: 'redpacket', name: '红包', icon: '🧧', color: '#F04438', type: 'income' },
  { id: 'refund', name: '报销', icon: '💳', color: '#06AED4', type: 'income' },
  { id: 'other-i', name: '其他', icon: '✨', color: '#98A2B3', type: 'income' },
];

const FALLBACK = { id: 'unknown', name: '未分类', icon: '❔', color: '#98A2B3', type: 'expense' };

const MAP = new Map(CATEGORIES.map((c) => [c.id, c]));

export function getCategory(id) {
  return MAP.get(id) || FALLBACK;
}

export function categoriesOf(type) {
  return CATEGORIES.filter((c) => c.type === type);
}
