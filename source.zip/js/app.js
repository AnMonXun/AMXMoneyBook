import { categoriesOf, getCategory } from './categories.js';
import { drawDonut, drawBars } from './charts.js';

/* ========== 基础工具 ========== */
const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];
const pad = (n) => String(n).padStart(2, '0');
const nf = new Intl.NumberFormat('zh-CN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

const fmt = (n) => nf.format(Math.abs(Number(n) || 0));
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
const esc = (s = '') =>
  String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

const ymd = (d = new Date()) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const currentMonth = () => ymd().slice(0, 7);
const monthOf = (dateStr) => dateStr.slice(0, 7);
const monthLabel = (m) => `${m.slice(0, 4)}年${Number(m.slice(5, 7))}月`;

function shiftMonth(month, delta) {
  const [y, m] = month.split('-').map(Number);
  const d = new Date(y, m - 1 + delta, 1);
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}`;
}

function dayLabel(dateStr) {
  const d = new Date(`${dateStr}T00:00:00`);
  const week = ['周日', '周一', '周二', '周三', '周四', '周五', '周六'][d.getDay()];
  return `${Number(dateStr.slice(5, 7))}月${Number(dateStr.slice(8, 10))}日 ${week}`;
}

const timeOf = (ts) => {
  const d = new Date(ts);
  return `${pad(d.getHours())}:${pad(d.getMinutes())}`;
};

function fmtRaw(raw) {
  if (!raw) return '0.00';
  const [int, dec] = raw.split('.');
  const intPart = (int || '0').replace(/^0+(?=\d)/, '');
  const withSep = intPart.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  return dec === undefined ? `${withSep}.00` : `${withSep}.${dec}`;
}

function splitAmount(n) {
  const s = fmt(n);
  const i = s.lastIndexOf('.');
  return { int: s.slice(0, i), dec: s.slice(i) };
}

/* ========== 数据层 ========== */
const STORE_KEY = 'moneybook:v1';
const defaultState = () => ({
  records: [],
  settings: { budget: 0, theme: 'auto', scheme: 'classic', font: 'md', lastBackupAt: 0, noticeDismissedAt: '' },
  savings: { goals: [], deposits: [] },
});
let state = defaultState();

const isValidRecord = (r) =>
  r && typeof r === 'object' && typeof r.amount === 'number' && Number.isFinite(r.amount) && typeof r.date === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(r.date) && (r.type === 'expense' || r.type === 'income');

function load() {
  try {
    const raw = localStorage.getItem(STORE_KEY);
    if (!raw) return;
    const data = JSON.parse(raw);
    state.records = Array.isArray(data.records) ? data.records.filter(isValidRecord) : [];
    state.settings = { ...defaultState().settings, ...(data.settings || {}) };
    if (data.savings && typeof data.savings === 'object') {
      state.savings.goals = Array.isArray(data.savings.goals)
        ? data.savings.goals.filter((g) => g && typeof g.name === 'string' && Number(g.target) > 0)
        : [];
      state.savings.deposits = Array.isArray(data.savings.deposits)
        ? data.savings.deposits.filter((d) => d && Number(d.amount) > 0 && typeof d.goalId === 'string')
        : [];
    }
  } catch (err) {
    console.warn('本地数据读取失败：', err);
  }
}

function persist() {
  try {
    localStorage.setItem(STORE_KEY, JSON.stringify(state));
  } catch (err) {
    console.warn('本地数据写入失败：', err);
    toast('存储空间不足，请先导出备份');
  }
}

/* ========== 视图状态 ========== */
const NAV = [
  {
    id: 'overview',
    label: '概览',
    icon: '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"><rect x="3" y="3" width="7.5" height="7.5" rx="2.4"/><rect x="13.5" y="3" width="7.5" height="7.5" rx="2.4"/><rect x="3" y="13.5" width="7.5" height="7.5" rx="2.4"/><rect x="13.5" y="13.5" width="7.5" height="7.5" rx="2.4"/></svg>',
  },
  {
    id: 'ledger',
    label: '账本',
    icon: '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"><path d="M4 20V10M4 20h16"/><path d="M8 20v-6M12 20V6M16 20v-9M20 20v-4"/></svg>',
  },
  {
    id: 'savings',
    label: '攒钱',
    icon: '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.9"><circle cx="12" cy="12" r="8.5"/><circle cx="12" cy="12" r="4.6"/><circle cx="12" cy="12" r="1.1" fill="currentColor" stroke="none"/></svg>',
  },
  {
    id: 'settings',
    label: '设置',
    icon: '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"><path d="M3 7h9M17 7h4M3 17h4M12 17h9"/><circle cx="14.5" cy="7" r="2.6"/><circle cx="9.5" cy="17" r="2.6"/></svg>',
  },
];

let view = 'overview';
let detailMonth = currentMonth();
let draft = null;
let savingsView = 'list';
let activeGoalId = null;
let depositDraft = null;
let goalDraft = null;

/* ========== 计算 ========== */
const sumOf = (list, type) => list.filter((r) => r.type === type).reduce((s, r) => s + r.amount, 0);
const recordsOfMonth = (m) => state.records.filter((r) => monthOf(r.date) === m);
const sortDesc = (a, b) => (a.date === b.date ? (b.createdAt || 0) - (a.createdAt || 0) : a.date < b.date ? 1 : -1);

function categoryTotals(month, type) {
  const map = new Map();
  for (const r of state.records) {
    if (r.type !== type || monthOf(r.date) !== month) continue;
    map.set(r.category, (map.get(r.category) || 0) + r.amount);
  }
  return [...map.entries()]
    .map(([id, value]) => ({ cat: getCategory(id), value }))
    .sort((a, b) => b.value - a.value);
}

function last6Months() {
  const out = [];
  for (let i = 5; i >= 0; i--) {
    const m = shiftMonth(currentMonth(), -i);
    const value = recordsOfMonth(m)
      .filter((r) => r.type === 'expense')
      .reduce((s, r) => s + r.amount, 0);
    out.push({ label: `${Number(m.slice(5, 7))}月`, value, month: m });
  }
  return out;
}

/* ========== 渲染：通用片段 ========== */
function rowHtml(r) {
  const c = getCategory(r.category);
  const time = r.createdAt ? timeOf(r.createdAt) : '';
  return `<button class="row" type="button" data-action="edit" data-id="${r.id}">
    <span class="row-icon" style="background:${c.color}1f">${c.icon}</span>
    <span class="row-main">
      <span class="row-title">${esc(r.note || c.name)}</span>
      <span class="row-sub">${esc(c.name)}${time ? ` · ${time}` : ''}</span>
    </span>
    <span class="row-amount ${r.type}">${r.type === 'income' ? '+' : '-'}${fmt(r.amount)}</span>
  </button>`;
}

const emptyHtml = (text = '还没有记录', btn = true) => `<div class="empty">
  <div class="emo">🧾</div>
  <p>${esc(text)}</p>
  ${btn ? '<button type="button" data-action="add">记第一笔</button>' : ''}
</div>`;

/* ========== 渲染：概览 ========== */
function renderOverview() {
  const m = currentMonth();
  const list = recordsOfMonth(m);
  const expense = sumOf(list, 'expense');
  const income = sumOf(list, 'income');
  const budget = Number(state.settings.budget) || 0;
  const pct = budget > 0 ? Math.min((expense / budget) * 100, 100) : 0;
  const over = budget > 0 && expense > budget;
  const days = new Date().getDate();
  const avg = expense / days;
  const { int, dec } = splitAmount(expense);
  const recent = [...state.records].sort(sortDesc).slice(0, 5);
  ensureSavings();
  const goals = state.savings.goals;
  const savedTotal = state.savings.deposits.reduce((s, d) => s + d.amount, 0);
  const activeGoals = goals.filter((g) => goalSaved(g.id) < g.target).length;

  return `
    ${noticeHtml()}
    <section class="hero">
      <div class="hero-top">
        <span>${monthLabel(m)}支出</span>
        ${budget > 0 ? `<span class="hero-pill">预算已用 ${Math.round((expense / budget) * 100)}%</span>` : ''}
      </div>
      <div class="hero-amount"><span class="cur">¥</span>${int}<span class="dec">${dec}</span></div>
      ${
        budget > 0
          ? `<div class="hero-bar ${over ? 'is-over' : ''}"><i style="width:${pct}%"></i></div>
             <div class="hero-note">${over ? `已超出预算 ¥${fmt(expense - budget)}` : `预算 ¥${fmt(budget)} · 还可花 ¥${fmt(budget - expense)}`}</div>`
          : `<div class="hero-note">还没有设置月度预算，去「设置」里设一个吧</div>`
      }
      <div class="hero-stats">
        <div><b>¥${fmt(income)}</b><span>本月收入</span></div>
        <div><b>¥${fmt(income - expense)}</b><span>本月结余</span></div>
        <div><b>¥${fmt(avg)}</b><span>日均支出</span></div>
      </div>
    </section>

    ${
      goals.length
        ? `<button class="savings-strip" type="button" data-nav="savings">
            <span class="ic">🎯</span>
            <span class="tx"><b>攒钱进行中</b><span>${activeGoals} 个目标 · 已攒 ¥${fmt(savedTotal)}</span></span>
            <span class="arrow">
              <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M9 5l7 7-7 7"/></svg>
            </span>
          </button>`
        : ''
    }

    <section class="card" style="margin-top:12px">
      <div class="section-head">
        <h2 class="section-title">最近记录</h2>
        <button class="text-btn" type="button" data-nav="ledger">查看账本</button>
      </div>
      ${
        recent.length
          ? `<div class="row-list">${recent.map(rowHtml).join('')}</div>`
          : emptyHtml('记下第一笔，账本就有了开头')
      }
    </section>
  `;
}

/* ========== 渲染：账本（明细 + 统计合并） ========== */
function renderLedger() {
  const list = recordsOfMonth(detailMonth).sort(sortDesc);
  const expense = sumOf(list, 'expense');
  const income = sumOf(list, 'income');
  const canNext = detailMonth < currentMonth();
  const items = categoryTotals(detailMonth, 'expense');
  const trend = last6Months();
  const { int, dec } = splitAmount(expense);
  const expenseCount = list.filter((r) => r.type === 'expense').length;
  const trendAvg = trend.reduce((s, t) => s + t.value, 0) / 6;

  const groups = new Map();
  for (const r of list) {
    if (!groups.has(r.date)) groups.set(r.date, []);
    groups.get(r.date).push(r);
  }

  return `
    <div class="month-switch">
      <button type="button" data-action="shift-month" data-scope="detail" data-delta="-1" aria-label="上个月">‹</button>
      <strong>${monthLabel(detailMonth)}</strong>
      <button type="button" data-action="shift-month" data-scope="detail" data-delta="1" ${canNext ? '' : 'disabled'} aria-label="下个月">›</button>
    </div>

    <div class="summary-row">
      <div>支出<b>¥${fmt(expense)}</b></div>
      <div>收入<b class="income">¥${fmt(income)}</b></div>
      <div>结余<b>¥${fmt(income - expense)}</b></div>
      <div>笔数<b>${list.length}</b></div>
    </div>

    ${
      expense > 0
        ? `<section class="card">
            <div class="section-head">
              <h2 class="section-title">钱花在哪</h2>
              <span class="section-sub">${items.length} 个分类</span>
            </div>
            <div class="donut-wrap">
              <div class="donut-box">
                <canvas id="donutChart"></canvas>
                <div class="donut-center"><b>¥${int}<span class="dec">${dec}</span></b><span>总支出</span></div>
              </div>
              <div class="legend">
                ${items
                  .map(
                    (t) => `<div class="legend-item">
                      <span class="dot" style="background:${t.cat.color}"></span>
                      <span class="nm">${esc(t.cat.name)}<em>${Math.round((t.value / expense) * 100)}%</em></span>
                      <span class="vl">¥${fmt(t.value)}</span>
                    </div>`
                  )
                  .join('')}
              </div>
            </div>
          </section>`
        : `<section class="card">${emptyHtml('这个月还没有支出记录', false)}</section>`
    }

    <section class="card" style="margin-top:12px">
      <div class="section-head">
        <h2 class="section-title">近 6 个月支出</h2>
        <span class="section-sub">月均 ¥${fmt(trendAvg)}</span>
      </div>
      <canvas class="chart" id="trendChart" height="148"></canvas>
      <div class="mini-stats">
        <div><b>¥${fmt(expenseCount ? expense / expenseCount : 0)}</b><span>笔均支出</span></div>
        <div><b>¥${fmt(income)}</b><span>本月收入</span></div>
        <div><b>¥${fmt(income - expense)}</b><span>本月结余</span></div>
      </div>
    </section>

    <div class="section-head" style="padding:20px 6px 4px">
      <h2 class="section-title">收支明细</h2>
      <span class="section-sub">共 ${list.length} 笔</span>
    </div>

    ${
      list.length
        ? [...groups.entries()]
            .map(([date, items]) => {
              const dayExpense = sumOf(items, 'expense');
              const dayIncome = sumOf(items, 'income');
              return `<div class="day-group">
                <div class="day-head">
                  <b>${dayLabel(date)}</b>
                  <span class="day-sum">${dayExpense ? `支出 ¥${fmt(dayExpense)}` : ''}${dayExpense && dayIncome ? ' · ' : ''}${dayIncome ? `收入 ¥${fmt(dayIncome)}` : ''}</span>
                </div>
                <div class="row-list">${items.map(rowHtml).join('')}</div>
              </div>`;
            })
            .join('')
        : emptyHtml('这个月还是空的')
    }
  `;
}

/* ========== 攒钱 ========== */
const GOAL_COLORS = ['#5b5bd6', '#12b76a', '#fdb022', '#ee46bc', '#2e90fa', '#f04438', '#7a5af8', '#06aed4'];

function ensureSavings() {
  if (!state.savings) state.savings = { goals: [], deposits: [] };
  if (!Array.isArray(state.savings.goals)) state.savings.goals = [];
  if (!Array.isArray(state.savings.deposits)) state.savings.deposits = [];
}

const goalById = (id) => state.savings.goals.find((g) => g.id === id);
const goalSaved = (id) =>
  state.savings.deposits.filter((d) => d.goalId === id).reduce((s, d) => s + d.amount, 0);
const goalDeposits = (id) =>
  state.savings.deposits
    .filter((d) => d.goalId === id)
    .sort((a, b) => (a.date === b.date ? (b.createdAt || 0) - (a.createdAt || 0) : a.date < b.date ? 1 : -1));

function nextGoalColor() {
  const used = state.savings.goals.map((g) => g.color);
  return GOAL_COLORS.find((c) => !used.includes(c)) || GOAL_COLORS[state.savings.goals.length % GOAL_COLORS.length];
}

function deadlineInfo(deadline) {
  if (!deadline) return null;
  const today = new Date(`${ymd()}T00:00:00`).getTime();
  const days = Math.round((new Date(`${deadline}T00:00:00`).getTime() - today) / 864e5);
  if (days < 0) return { text: `已超期 ${-days} 天`, over: true };
  if (days === 0) return { text: '今天截止', over: false };
  return { text: `还剩 ${days} 天`, over: false };
}

function goalCardHtml(g) {
  const saved = goalSaved(g.id);
  const pct = g.target > 0 ? Math.min((saved / g.target) * 100, 100) : 0;
  const done = saved >= g.target;
  const dl = deadlineInfo(g.deadline);
  return `<button class="goal-card" type="button" data-action="open-goal" data-id="${g.id}">
    <div class="goal-top">
      <span class="goal-name">${esc(g.name)}${done ? '<em class="goal-badge">已达成</em>' : ''}</span>
      <span class="goal-pct">${Math.round(pct)}%</span>
    </div>
    <div class="track"><i style="width:${pct}%;background:${g.color}"></i></div>
    <div class="goal-meta">
      <span>已攒 <b>¥${fmt(saved)}</b></span>
      <span>目标 ¥${fmt(g.target)}</span>
    </div>
    ${dl ? `<div class="goal-dl ${dl.over ? 'is-over' : ''}">${done ? '目标已完成' : esc(dl.text)}${g.deadline ? ` · ${g.deadline}` : ''}</div>` : ''}
  </button>`;
}

function depositRowHtml(d, g) {
  return `<button class="row" type="button" data-action="del-deposit" data-id="${d.id}" title="点击删除">
    <span class="row-icon" style="background:${g.color}1f">💰</span>
    <span class="row-main">
      <span class="row-title">${esc(d.note || '存入')}</span>
      <span class="row-sub">${esc(d.date)}</span>
    </span>
    <span class="row-amount deposit">+${fmt(d.amount)}</span>
  </button>`;
}

function renderSavings() {
  ensureSavings();
  if (savingsView === 'detail') {
    const g = goalById(activeGoalId);
    if (g) return renderGoalDetail(g);
    savingsView = 'list';
  }

  const goals = state.savings.goals;
  const totalSaved = state.savings.deposits.reduce((s, d) => s + d.amount, 0);
  const active = goals.filter((g) => goalSaved(g.id) < g.target).length;
  const { int, dec } = splitAmount(totalSaved);

  return `
    <section class="save-hero">
      <div class="save-hero-top">
        <span>累计攒下</span>
        <span class="pill">${active} 个进行中</span>
      </div>
      <div class="save-hero-amt"><span class="cur" style="font-size:22px;opacity:.85">¥</span>${int}<span class="dec">${dec}</span></div>
      <div class="save-hero-sub">共 ${state.savings.deposits.length} 笔存入 · ${goals.length} 个目标</div>
    </section>

    ${
      goals.length
        ? `<div class="goal-list">${goals.map(goalCardHtml).join('')}</div>`
        : `<section class="card" style="margin-top:12px">${emptyHtml('还没有攒钱目标，先建一个吧', false)}</section>`
    }

    <button class="dashed-btn" type="button" data-action="new-goal">＋ 新建攒钱目标</button>
  `;
}

function renderGoalDetail(g) {
  const saved = goalSaved(g.id);
  const list = goalDeposits(g.id);
  const pct = g.target > 0 ? Math.min((saved / g.target) * 100, 100) : 0;
  const done = saved >= g.target;
  const dl = deadlineInfo(g.deadline);

  return `
    <div class="detail-head">
      <button class="icon-btn" type="button" data-action="close-goal" aria-label="返回">
        <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 5l-7 7 7 7"/></svg>
      </button>
      <div class="detail-title">${esc(g.name)}</div>
      <button class="icon-btn" type="button" data-action="edit-goal" data-id="${g.id}">编辑</button>
    </div>

    <section class="goal-detail-card" style="--gc:${g.color}">
      <div class="gd-amt">¥${fmt(saved)}</div>
      <div class="gd-target">目标 ¥${fmt(g.target)} · ${done ? '已达成 🎉' : `还差 ¥${fmt(g.target - saved)}`}</div>
      <div class="track"><i style="width:${pct}%"></i></div>
      <div class="gd-meta">${list.length} 笔存入${dl ? ` · ${esc(dl.text)}` : ''}${g.deadline ? ` · 截止 ${g.deadline}` : ''}</div>
    </section>

    <button class="primary-btn" type="button" data-action="deposit" data-id="${g.id}" style="margin-top:14px">攒一笔</button>

    <section class="card" style="margin-top:12px">
      <div class="section-head"><h2 class="section-title">存入记录</h2><span class="section-sub">点击可删除</span></div>
      ${
        list.length
          ? `<div class="row-list">${list.map((d) => depositRowHtml(d, g)).join('')}</div>`
          : `<div class="empty" style="padding:26px 0"><p>还没有存入，点上面的「攒一笔」</p></div>`
      }
    </section>

    <button class="btn danger" type="button" data-action="delete-goal" data-id="${g.id}" style="width:100%;height:44px;margin-top:12px">删除这个目标</button>
  `;
}

/* ========== 渲染：设置 ========== */
const SCHEMES = [
  { id: 'classic', name: '经典', swatches: ['#5b5bd6', '#12b76a', '#f04438'] },
  { id: 'tech', name: '科技风', swatches: ['#0ea5e9', '#22d3ee', '#10b981'] },
  { id: 'sky', name: '蓝天白云', swatches: ['#3b95f5', '#6db8ff', '#0ea5e9'] },
  { id: 'spring', name: '春意盎然', swatches: ['#52b788', '#74c69d', '#fdb022'] },
  { id: 'peach', name: '桃花粉', swatches: ['#e64980', '#f783ac', '#ffa8c5'] },
  { id: 'meteor', name: '午夜流星', swatches: ['#7048e8', '#9775fa', '#b197fc'] },
];

const FONT_SIZES = [
  { id: 'sm', name: '小' },
  { id: 'md', name: '中' },
  { id: 'lg', name: '大' },
];

function renderSettings() {
  const budget = Number(state.settings.budget) || 0;
  const theme = state.settings.theme || 'auto';
  const scheme = state.settings.scheme || 'classic';
  const font = state.settings.font || 'md';
  const first = [...state.records].sort((a, b) => (a.date < b.date ? -1 : 1))[0];
  const days = first ? Math.max(1, Math.round((Date.now() - new Date(`${first.date}T00:00:00`).getTime()) / 864e5) + 1) : 0;
  const totalExpense = state.records.filter((r) => r.type === 'expense').reduce((s, r) => s + r.amount, 0);

  const themeBtn = (val, label) =>
    `<button class="btn ${theme === val ? 'primary' : ''}" type="button" data-action="set-theme" data-value="${val}">${label}</button>`;

  return `
    <section class="card">
      <div class="setting-row">
        <div class="lbl"><b>月度预算</b><span>用于概览页的预算进度提醒</span></div>
        <div class="input-money">
          <span>¥</span>
          <input id="budgetInput" type="number" min="0" step="100" inputmode="decimal" placeholder="0" value="${budget || ''}" />
        </div>
      </div>
      <div class="setting-row">
        <div class="lbl"><b>显示模式</b><span>跟随系统或手动指定</span></div>
        <div class="btn-group">
          ${themeBtn('auto', '自动')}
          ${themeBtn('light', '浅色')}
          ${themeBtn('dark', '深色')}
        </div>
      </div>
      <div class="setting-row column">
        <div class="lbl"><b>主题风格</b><span>换一套配色，深浅色都适配</span></div>
        <div class="scheme-grid">
          ${SCHEMES.map(
            (s) => `<button class="scheme-btn ${scheme === s.id ? 'is-on' : ''}" type="button" data-action="set-scheme" data-value="${s.id}">
              <span class="swatches">${s.swatches.map((c) => `<i style="background:${c}"></i>`).join('')}</span>
              <span class="nm">${s.name}</span>
            </button>`
          ).join('')}
        </div>
      </div>
      <div class="setting-row">
        <div class="lbl"><b>字体大小</b><span>小 / 中 / 大，立刻生效</span></div>
        <div class="btn-group">
          ${FONT_SIZES.map(
            (f) => `<button class="btn ${font === f.id ? 'primary' : ''}" type="button" data-action="set-font" data-value="${f.id}">${f.name}</button>`
          ).join('')}
        </div>
      </div>
      ${
        isStandalone()
          ? `<div class="setting-row">
              <div class="lbl"><b>已安装为应用</b><span>独立图标打开，数据与浏览器无关</span></div>
              <span class="btn" style="color:var(--income);pointer-events:none">✓ 已安装</span>
            </div>`
          : `<div class="setting-row">
              <div class="lbl"><b>安装到主屏幕</b><span>离线可用、全屏、无地址栏</span></div>
              <button class="btn primary" type="button" data-action="install-app">安装</button>
            </div>`
      }
    </section>

    <section class="card" style="margin-top:12px">
      <div class="setting-row">
        <div class="lbl"><b>数据备份</b><span>${backupStatusText()}</span></div>
        <div class="btn-group">
          <button class="btn" type="button" data-action="export-json">导出</button>
          <button class="btn" type="button" data-action="import-json">导入</button>
        </div>
      </div>
      <div class="setting-row">
        <div class="lbl"><b>导出表格</b><span>CSV 可直接用 Excel 打开</span></div>
        <button class="btn" type="button" data-action="export-csv">导出 CSV</button>
      </div>
      <div class="setting-row">
        <div class="lbl"><b>清空数据</b><span>共 ${state.records.length} 笔记录，操作不可恢复</span></div>
        <button class="btn danger" type="button" data-action="clear-all">清空</button>
      </div>
    </section>

    <section class="card" style="margin-top:12px">
      <div class="section-head"><h2 class="section-title">使用小结</h2></div>
      <div class="summary-row" style="margin:0;border:0;padding:0;background:none">
        <div>记账天数<b>${days || 0} 天</b></div>
        <div>累计支出<b>¥${fmt(totalExpense)}</b></div>
        <div>累计笔数<b>${state.records.length}</b></div>
      </div>
      <p class="hint">所有数据只保存在当前设备的浏览器里，不会上传到任何服务器。清理浏览器数据前请先导出备份。</p>
    </section>
  `;
}

/* ========== 渲染主流程 ========== */
const RENDERERS = {
  overview: renderOverview,
  ledger: renderLedger,
  savings: renderSavings,
  settings: renderSettings,
};

function renderNav() {
  const rail = $('#rail');
  const tabbar = $('#tabbar');
  const item = (n) =>
    `<button class="rail-item ${n.id === view ? 'is-active' : ''}" type="button" data-nav="${n.id}">${n.icon}<span>${n.label}</span></button>`;
  const tab = (n) =>
    `<button class="tab-item ${n.id === view ? 'is-active' : ''}" type="button" data-nav="${n.id}">${n.icon}<span>${n.label}</span></button>`;

  rail.innerHTML = `
    <div class="rail-brand">
      <div class="rail-mark">¥</div>
      <div class="rail-name"><b>记账本</b><span>MoneyBook</span></div>
    </div>
    <div class="rail-nav">${NAV.map(item).join('')}</div>
    <div class="rail-foot">
      <button class="rail-add" type="button" data-action="add">
        <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg>
        记一笔
      </button>
      <div class="rail-tip">数据只存在本机<br/>记得定期导出备份</div>
    </div>`;

  const tabAdd = `<button class="tab-add" type="button" data-action="add" aria-label="记一笔"><i>
      <svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg>
    </i></button>`;

  tabbar.innerHTML = NAV.map((n, i) => (i === 2 ? tabAdd + tab(n) : tab(n))).join('');

  $('#topTitle').textContent = NAV.find((n) => n.id === view)?.label || '';
}

function render() {
  $('#views').innerHTML = `<section class="view">${RENDERERS[view]()}</section>`;
  renderNav();
  bindViewEvents();
  afterRender();
}

function afterRender() {
  if (view !== 'ledger') return;
  const donut = $('#donutChart');
  if (donut) {
    const items = categoryTotals(detailMonth, 'expense').map((t) => ({ value: t.value, color: t.cat.color }));
    drawDonut(donut, items);
  }
  const trend = $('#trendChart');
  if (trend) drawBars(trend, last6Months(), { activeIndex: 5 });
}

function bindViewEvents() {
  const budgetInput = $('#budgetInput');
  if (budgetInput) {
    budgetInput.addEventListener('change', () => {
      const v = Math.max(0, Math.round(Number(budgetInput.value) || 0));
      state.settings.budget = v;
      persist();
      toast(v ? `预算已设为 ¥${fmt(v)}` : '已取消月度预算');
    });
  }
}

function setView(next) {
  if (next === view) return;
  view = next;
  if (next !== 'savings') {
    savingsView = 'list';
    activeGoalId = null;
  }
  render();
  window.scrollTo(0, 0);
}

/* ========== 记账面板 ========== */
const sheet = $('#sheet');
const scrim = $('#scrim');
const catGrid = $('#catGrid');
const entryDate = $('#entryDate');
const entryNote = $('#entryNote');
const amountVal = $('#amountVal');

const sheetEls = { entry: sheet, deposit: $('#depositSheet'), goal: $('#goalSheet') };
let activeSheet = null;

function showSheet(name) {
  if (activeSheet && activeSheet !== name) hideSheet();
  activeSheet = name;
  sheetEls[name].classList.add('is-open');
  scrim.classList.add('is-open');
  document.body.style.overflow = 'hidden';
}

function hideSheet() {
  if (!activeSheet) return;
  sheetEls[activeSheet].classList.remove('is-open');
  activeSheet = null;
  scrim.classList.remove('is-open');
  document.body.style.overflow = '';
}

/** 只保留合法金额字符：数字 + 一个小数点，整数最多 8 位、小数最多 2 位 */
function sanitizeAmount(raw) {
  let s = String(raw).replace(/[^\d.]/g, '');
  const dot = s.indexOf('.');
  if (dot >= 0) {
    const int = s.slice(0, dot).replace(/\./g, '');
    const dec = s.slice(dot + 1).replace(/\./g, '').slice(0, 2);
    s = int.replace(/^0+(?=\d)/, '') + '.' + dec;
  } else {
    s = s.replace(/^0+(?=\d)/, '').slice(0, 8);
  }
  return s;
}
const deleteEntry = $('#deleteEntry');
const saveEntry = $('#saveEntry');

function openEntry(id) {
  if (id) {
    const r = state.records.find((x) => x.id === id);
    if (!r) return;
    draft = { id: r.id, type: r.type, amount: String(r.amount), category: r.category, date: r.date, note: r.note || '' };
  } else {
    const last = [...state.records].sort(sortDesc).find((r) => r.type === 'expense');
    draft = { id: null, type: 'expense', amount: '', category: last?.category || 'food', date: ymd(), note: '' };
  }
  paintSheet();
  showSheet('entry');
  setTimeout(() => amountVal.focus(), 280);
}

function closeEntry() {
  hideSheet();
  draft = null;
}

function paintSheet() {
  if (!draft) return;
  $$('#entryType button').forEach((b) => b.classList.toggle('is-on', b.dataset.type === draft.type));
  amountVal.value = draft.amount ? fmtRaw(draft.amount) : '';
  catGrid.innerHTML = categoriesOf(draft.type)
    .map(
      (c) => `<button class="cat ${c.id === draft.category ? 'is-on' : ''}" type="button" data-cat="${c.id}">
        <span class="emo" style="background:${c.color}1f">${c.icon}</span>
        <span class="nm">${esc(c.name)}</span>
      </button>`
    )
    .join('');
  entryDate.value = draft.date;
  entryNote.value = draft.note;
  deleteEntry.hidden = !draft.id;
  const ok = Number(draft.amount) > 0;
  saveEntry.disabled = !ok;
  saveEntry.textContent = draft.id ? '保存修改' : '保存';
}

function saveDraft() {
  if (!draft) return;
  const amount = Math.round(Number(draft.amount) * 100) / 100;
  if (!(amount > 0)) {
    toast('先输入金额');
    return;
  }
  const note = draft.note.trim();
  if (draft.id) {
    const rec = state.records.find((x) => x.id === draft.id);
    if (rec) Object.assign(rec, { type: draft.type, amount, category: draft.category, date: draft.date, note, updatedAt: Date.now() });
  } else {
    state.records.push({
      id: uid(),
      type: draft.type,
      amount,
      category: draft.category,
      date: draft.date,
      note,
      createdAt: Date.now(),
    });
  }
  const wasEdit = Boolean(draft.id);
  const month = draft.date.slice(0, 7);
  persist();
  closeEntry();
  if (month === detailMonth) detailMonth = month;
  render();
  toast(wasEdit ? '已更新' : `已记入 ${monthLabel(month)}`);
}

/* ========== 数据导入导出 ========== */
function download(filename, content, type) {
  // 本地文件模式（file://）和原生 App 壳内，浏览器不允许直接下载，改为展示文本让用户手动保存
  const isNative = !!(window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform());
  if (location.protocol === 'file:' || isNative) {
    showTextBackup(filename, content);
    return;
  }
  const blob = new Blob([content], { type });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function showTextBackup(filename, content) {
  const old = document.querySelector('.backup-modal');
  if (old) old.remove();

  const el = document.createElement('div');
  el.className = 'backup-modal';
  el.innerHTML = `
    <div class="backup-box">
      <div class="backup-head">
        <b>${esc(filename)}</b>
        <button class="icon-btn ghost" type="button" data-backup-close aria-label="关闭">
          <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg>
        </button>
      </div>
      <p class="backup-tip">本地文件模式下浏览器不允许直接下载。点「全选并复制」，粘贴到备忘录或发给自己保存。</p>
      <textarea readonly spellcheck="false"></textarea>
      <div class="backup-actions">
        <button class="btn primary" type="button" data-backup-copy>全选并复制</button>
        <button class="btn" type="button" data-backup-close>关闭</button>
      </div>
    </div>`;

  document.body.appendChild(el);
  const ta = el.querySelector('textarea');
  ta.value = content;

  el.addEventListener('click', (e) => {
    if (e.target === el || e.target.closest('[data-backup-close]')) {
      el.remove();
      return;
    }
    if (e.target.closest('[data-backup-copy]')) {
      ta.focus();
      ta.select();
      let ok = false;
      try {
        ok = document.execCommand('copy');
      } catch (err) {
        ok = false;
      }
      if (!ok && navigator.clipboard) {
        navigator.clipboard
          .writeText(content)
          .then(() => toast('已复制到剪贴板'))
          .catch(() => toast('请长按文本框手动全选复制'));
        return;
      }
      toast(ok ? '已复制到剪贴板' : '请长按文本框手动全选复制');
    }
  });

  requestAnimationFrame(() => el.classList.add('is-on'));
}

function exportJSON() {
  if (!state.records.length) return toast('还没有数据可以导出');
  state.settings.lastBackupAt = Date.now();
  persist();
  const payload = {
    app: 'moneybook',
    version: 1,
    exportedAt: new Date().toISOString(),
    settings: state.settings,
    records: [...state.records].sort(sortDesc),
    savings: {
      goals: state.savings.goals,
      deposits: state.savings.deposits,
    },
  };
  download(`记账本备份-${ymd()}.json`, JSON.stringify(payload, null, 2), 'application/json');
  toast('备份已导出');
}

function exportCSV() {
  if (!state.records.length) return toast('还没有数据可以导出');
  state.settings.lastBackupAt = Date.now();
  persist();
  const rows = [['日期', '类型', '分类', '金额', '备注']];
  [...state.records]
    .sort((a, b) => (a.date < b.date ? -1 : 1))
    .forEach((r) => rows.push([r.date, r.type === 'expense' ? '支出' : '收入', getCategory(r.category).name, r.amount.toFixed(2), r.note || '']));
  const csv = `\uFEFF${rows.map((row) => row.map((cell) => `"${String(cell).replace(/"/g, '""')}"`).join(',')).join('\r\n')}`;
  download(`记账本-${ymd()}.csv`, csv, 'text/csv;charset=utf-8');
  toast('CSV 已导出');
}

async function importJSON(file) {
  try {
    const data = JSON.parse(await file.text());
    const records = Array.isArray(data) ? data : data.records;
    if (!Array.isArray(records)) throw new Error('文件格式不正确');
    const ids = new Set(state.records.map((r) => r.id));

    // 攒钱目标与存入记录
    if (data.savings && typeof data.savings === 'object') {
      const goalIds = new Set(state.savings.goals.map((g) => g.id));
      for (const raw of Array.isArray(data.savings.goals) ? data.savings.goals : []) {
        if (!raw || typeof raw.name !== 'string' || !(Number(raw.target) > 0)) continue;
        const id = goalIds.has(raw.id) ? uid() : raw.id || uid();
        goalIds.add(id);
        state.savings.goals.push({
          id,
          name: raw.name.slice(0, 12),
          target: Math.round(Number(raw.target) * 100) / 100,
          deadline: /^\d{4}-\d{2}-\d{2}$/.test(raw.deadline || '') ? raw.deadline : '',
          color: nextGoalColor(),
          createdAt: raw.createdAt || Date.now(),
        });
      }
      const depIds = new Set(state.savings.deposits.map((d) => d.id));
      for (const raw of Array.isArray(data.savings.deposits) ? data.savings.deposits : []) {
        if (!raw || !(Number(raw.amount) > 0) || !/^\d{4}-\d{2}-\d{2}$/.test(raw.date || '')) continue;
        if (!state.savings.goals.some((g) => g.id === raw.goalId)) continue;
        const id = depIds.has(raw.id) ? uid() : raw.id || uid();
        depIds.add(id);
        state.savings.deposits.push({
          id,
          goalId: raw.goalId,
          amount: Math.round(Number(raw.amount) * 100) / 100,
          date: raw.date,
          note: String(raw.note || '').slice(0, 30),
          createdAt: raw.createdAt || Date.now(),
        });
      }
    }

    let added = 0;
    for (const raw of records) {
      if (!isValidRecord(raw)) continue;
      const rec = {
        id: ids.has(raw.id) ? uid() : raw.id || uid(),
        type: raw.type,
        amount: Math.round(raw.amount * 100) / 100,
        category: raw.category || 'other-e',
        date: raw.date,
        note: String(raw.note || '').slice(0, 30),
        createdAt: raw.createdAt || Date.now(),
      };
      ids.add(rec.id);
      state.records.push(rec);
      added += 1;
    }
    persist();
    render();
    toast(added ? `已导入 ${added} 笔记录` : '没有可导入的记录');
  } catch (err) {
    console.error(err);
    toast('导入失败：文件无法解析');
  }
}

/* ========== 主题 ========== */
function resolvedTheme() {
  const t = state.settings.theme || 'auto';
  if (t !== 'auto') return t;
  return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
}

function applyAppearance() {
  document.documentElement.dataset.theme = resolvedTheme();
  document.documentElement.dataset.scheme = state.settings.scheme || 'classic';
  document.documentElement.dataset.font = state.settings.font || 'md';
  const btn = $('#themeBtn');
  if (!btn) return;
  btn.innerHTML =
    resolvedTheme() === 'dark'
      ? '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"><path d="M20 14.5A8.5 8.5 0 019.5 4a8.5 8.5 0 1010.5 10.5z"/></svg>'
      : '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"><circle cx="12" cy="12" r="4.2"/><path d="M12 2.8v2M12 19.2v2M2.8 12h2M19.2 12h2M5.5 5.5l1.4 1.4M17.1 17.1l1.4 1.4M18.5 5.5l-1.4 1.4M6.9 17.1l-1.4 1.4"/></svg>';
}

/* ========== PWA：安装引导 / 备份提醒 ========== */
let installPrompt = null;

const isStandalone = () =>
  window.matchMedia('(display-mode: standalone)').matches ||
  window.matchMedia('(display-mode: minimal-ui)').matches ||
  window.navigator.standalone === true;

function backupStatusText() {
  const last = state.settings.lastBackupAt || 0;
  if (!state.records.length) return '导出 JSON，换设备时可导入恢复';
  if (!last) return '还没备份过，建议现在导出一份';
  const days = Math.floor((Date.now() - last) / 864e5);
  if (days <= 0) return `今天已备份 · 共 ${state.records.length} 笔`;
  if (days === 1) return '昨天备份过一次';
  return `${days} 天前备份过，建议再导一份`;
}

const closeBtn = `<button class="close" type="button" data-action="dismiss-notice" aria-label="今天不再提示">
  <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg>
</button>`;

function noticeHtml() {
  if (state.settings.noticeDismissedAt === ymd()) return '';
  const out = [];

  if (!isStandalone() && installPrompt) {
    out.push(`<div class="notice">
      <span class="ic">📲</span>
      <span class="tx"><b>装到主屏幕</b><span>打开就是全屏，断网也能记</span></span>
      <button class="act" type="button" data-action="install-app">安装</button>
      ${closeBtn}
    </div>`);
  }

  const last = state.settings.lastBackupAt || 0;
  if (state.records.length) {
    const days = last ? Math.floor((Date.now() - last) / 864e5) : Infinity;
    if (days >= 7) {
      out.push(`<div class="notice">
        <span class="ic">💾</span>
        <span class="tx"><b>备份账本</b><span>${esc(last ? `上次备份在 ${days} 天前` : '账本还没有备份过')} · ${state.records.length} 笔记录</span></span>
        <button class="act" type="button" data-action="export-json">导出</button>
        ${closeBtn}
      </div>`);
    }
  }

  return out.join('');
}

async function requestInstall() {
  if (!installPrompt) {
    toast('用浏览器菜单里的「安装应用」或「添加到主屏幕」');
    return;
  }
  installPrompt.prompt();
  const choice = await installPrompt.userChoice.catch(() => null);
  installPrompt = null;
  render();
  toast(choice && choice.outcome === 'accepted' ? '已开始安装' : '已取消安装');
}

/* ========== Toast ========== */
let toastTimer;
function toast(msg) {
  const el = $('#toast');
  el.textContent = msg;
  el.classList.add('is-on');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove('is-on'), 1900);
}

/* ========== 事件绑定 ========== */
document.addEventListener('click', (e) => {
  const navEl = e.target.closest('[data-nav]');
  if (navEl) {
    setView(navEl.dataset.nav);
    return;
  }
  const actEl = e.target.closest('[data-action]');
  if (!actEl) return;

  const { action } = actEl.dataset;
  switch (action) {
    case 'add':
      openEntry();
      break;
    case 'edit':
      openEntry(actEl.dataset.id);
      break;
    case 'shift-month': {
      const next = shiftMonth(detailMonth, Number(actEl.dataset.delta));
      if (next > currentMonth()) return;
      detailMonth = next;
      render();
      break;
    }
    case 'export-json':
      exportJSON();
      break;
    case 'export-csv':
      exportCSV();
      break;
    case 'import-json':
      $('#importFile').click();
      break;
    case 'clear-all':
      if (!state.records.length) {
        toast('还没有数据');
        break;
      }
      if (window.confirm(`确定清空全部 ${state.records.length} 笔记录？建议先导出备份，此操作不可恢复。`)) {
        state.records = [];
        persist();
        render();
        toast('已清空');
      }
      break;
    case 'set-theme':
      state.settings.theme = actEl.dataset.value;
      persist();
      applyAppearance();
      afterRender();
      if (view === 'settings') render();
      break;
    case 'set-scheme':
      state.settings.scheme = actEl.dataset.value;
      persist();
      applyAppearance();
      afterRender();
      render();
      break;
    case 'set-font':
      state.settings.font = actEl.dataset.value;
      persist();
      applyAppearance();
      render();
      break;
    case 'install-app':
      requestInstall();
      break;
    case 'dismiss-notice':
      state.settings.noticeDismissedAt = ymd();
      persist();
      render();
      break;
    case 'new-goal':
      openGoalSheet();
      break;
    case 'edit-goal':
      openGoalSheet(actEl.dataset.id);
      break;
    case 'open-goal':
      savingsView = 'detail';
      activeGoalId = actEl.dataset.id;
      render();
      window.scrollTo(0, 0);
      break;
    case 'close-goal':
      savingsView = 'list';
      activeGoalId = null;
      render();
      break;
    case 'deposit':
      openDepositSheet(actEl.dataset.id);
      break;
    case 'delete-goal': {
      const g = goalById(actEl.dataset.id);
      if (!g) break;
      const count = goalDeposits(g.id).length;
      if (!window.confirm(`删除「${g.name}」？里面的 ${count} 笔存入记录也会一起删掉。`)) break;
      state.savings.goals = state.savings.goals.filter((x) => x.id !== g.id);
      state.savings.deposits = state.savings.deposits.filter((d) => d.goalId !== g.id);
      savingsView = 'list';
      activeGoalId = null;
      persist();
      render();
      toast('目标已删除');
      break;
    }
    case 'del-deposit': {
      const d = state.savings.deposits.find((x) => x.id === actEl.dataset.id);
      if (!d) break;
      if (!window.confirm(`删除这笔 ¥${fmt(d.amount)} 的存入？`)) break;
      state.savings.deposits = state.savings.deposits.filter((x) => x.id !== d.id);
      persist();
      render();
      toast('已删除');
      break;
    }
    default:
      break;
  }
});

window.addEventListener('beforeinstallprompt', (e) => {
  e.preventDefault();
  installPrompt = e;
  render();
});

window.addEventListener('appinstalled', () => {
  installPrompt = null;
  render();
});

$('#topAdd').addEventListener('click', () => openEntry());
$('#themeBtn').addEventListener('click', () => {
  state.settings.theme = resolvedTheme() === 'dark' ? 'light' : 'dark';
  persist();
  applyAppearance();
  afterRender();
  if (view === 'settings') render();
});
scrim.addEventListener('click', hideSheet);
$('#sheetClose').addEventListener('click', hideSheet);

$('#entryType').addEventListener('click', (e) => {
  const btn = e.target.closest('[data-type]');
  if (!btn || !draft) return;
  const type = btn.dataset.type;
  if (type === draft.type) return;
  draft.type = type;
  const list = categoriesOf(type);
  if (!list.some((c) => c.id === draft.category)) draft.category = list[0].id;
  paintSheet();
});

catGrid.addEventListener('click', (e) => {
  const btn = e.target.closest('[data-cat]');
  if (!btn || !draft) return;
  draft.category = btn.dataset.cat;
  paintSheet();
});

entryDate.addEventListener('change', () => {
  if (!draft) return;
  draft.date = entryDate.value || ymd();
  paintSheet();
});

entryNote.addEventListener('input', () => {
  if (!draft) return;
  draft.note = entryNote.value;
});
saveEntry.addEventListener('click', saveDraft);

/* ---- 攒一笔面板 ---- */
const depositGoals = $('#depositGoals');
const depositAmount = $('#depositAmount');
const depositDate = $('#depositDate');
const depositNote = $('#depositNote');
const depositSave = $('#depositSave');

function openDepositSheet(goalId) {
  ensureSavings();
  if (!state.savings.goals.length) {
    toast('先创建一个攒钱目标');
    return;
  }
  depositDraft = {
    goalId: goalId && goalById(goalId) ? goalId : state.savings.goals[0].id,
    amount: '',
    date: ymd(),
    note: '',
  };
  paintDepositSheet();
  showSheet('deposit');
  setTimeout(() => depositAmount.focus(), 280);
}

function paintDepositSheet() {
  if (!depositDraft) return;
  depositGoals.innerHTML = state.savings.goals
    .map(
      (g) => `<button class="chip ${g.id === depositDraft.goalId ? 'is-on' : ''}" type="button" data-goal="${g.id}">
        <span class="dot" style="background:${g.color}"></span>${esc(g.name)}
      </button>`
    )
    .join('');
  depositAmount.value = depositDraft.amount ? fmtRaw(depositDraft.amount) : '';
  depositDate.value = depositDraft.date;
  depositNote.value = depositDraft.note;
  depositSave.disabled = !(Number(depositDraft.amount) > 0);
}

function saveDeposit() {
  if (!depositDraft) return;
  const amount = Math.round(Number(depositDraft.amount) * 100) / 100;
  if (!(amount > 0)) return toast('先输入金额');
  const g = goalById(depositDraft.goalId);
  state.savings.deposits.push({
    id: uid(),
    goalId: depositDraft.goalId,
    amount,
    date: depositDraft.date,
    note: depositDraft.note.trim(),
    createdAt: Date.now(),
  });
  persist();
  hideSheet();
  render();
  const saved = goalSaved(depositDraft.goalId);
  const tip = g && saved >= g.target ? '，目标达成 🎉' : '';
  toast(`已存入 ¥${fmt(amount)}${tip}`);
}

depositGoals.addEventListener('click', (e) => {
  const chip = e.target.closest('[data-goal]');
  if (!chip || !depositDraft) return;
  depositDraft.goalId = chip.dataset.goal;
  paintDepositSheet();
});

depositAmount.addEventListener('input', () => {
  if (!depositDraft) return;
  const cleaned = sanitizeAmount(depositAmount.value);
  if (cleaned !== depositAmount.value) depositAmount.value = cleaned;
  depositDraft.amount = cleaned;
  depositSave.disabled = !(Number(cleaned) > 0);
});

depositAmount.addEventListener('focus', () => {
  if (depositDraft) depositAmount.value = depositDraft.amount;
});

depositAmount.addEventListener('blur', () => {
  if (depositDraft) depositAmount.value = depositDraft.amount ? fmtRaw(depositDraft.amount) : '';
});

depositDate.addEventListener('change', () => {
  if (depositDraft) depositDraft.date = depositDate.value || ymd();
});

depositNote.addEventListener('input', () => {
  if (depositDraft) depositDraft.note = depositNote.value;
});

depositSave.addEventListener('click', saveDeposit);
$('#depositClose').addEventListener('click', hideSheet);

/* ---- 新建 / 编辑目标面板 ---- */
const goalName = $('#goalName');
const goalTarget = $('#goalTarget');
const goalDeadline = $('#goalDeadline');
const goalSaveBtn = $('#goalSave');
const goalSheetTitle = $('#goalSheetTitle');

function openGoalSheet(id) {
  ensureSavings();
  if (id) {
    const g = goalById(id);
    if (!g) return;
    goalDraft = { id: g.id, name: g.name, target: String(g.target), deadline: g.deadline || '' };
    goalSheetTitle.textContent = '编辑目标';
    goalSaveBtn.textContent = '保存修改';
  } else {
    goalDraft = { id: null, name: '', target: '', deadline: '' };
    goalSheetTitle.textContent = '新建目标';
    goalSaveBtn.textContent = '创建目标';
  }
  goalName.value = goalDraft.name;
  goalTarget.value = goalDraft.target ? fmtRaw(goalDraft.target) : '';
  goalDeadline.value = goalDraft.deadline;
  showSheet('goal');
  setTimeout(() => goalName.focus(), 280);
}

function saveGoal() {
  const name = goalName.value.trim();
  const target = Math.round(Number(sanitizeAmount(goalTarget.value)) * 100) / 100;
  if (!name) {
    toast('给目标起个名字');
    goalName.focus();
    return;
  }
  if (!(target > 0)) {
    toast('填一下目标金额');
    goalTarget.focus();
    return;
  }
  if (goalDraft.id) {
    const g = goalById(goalDraft.id);
    if (g) Object.assign(g, { name, target, deadline: goalDeadline.value || '' });
  } else {
    state.savings.goals.push({
      id: uid(),
      name,
      target,
      deadline: goalDeadline.value || '',
      color: nextGoalColor(),
      createdAt: Date.now(),
    });
  }
  persist();
  hideSheet();
  render();
  toast(goalDraft.id ? '目标已更新' : '目标已创建');
}

goalSaveBtn.addEventListener('click', saveGoal);
$('#goalClose').addEventListener('click', hideSheet);

goalTarget.addEventListener('blur', () => {
  const cleaned = sanitizeAmount(goalTarget.value);
  goalTarget.value = cleaned ? fmtRaw(cleaned) : '';
});
deleteEntry.addEventListener('click', () => {
  if (!draft?.id) return;
  if (!window.confirm('删除这笔记录？')) return;
  state.records = state.records.filter((r) => r.id !== draft.id);
  persist();
  closeEntry();
  render();
  toast('已删除');
});

$('#importFile').addEventListener('change', (e) => {
  const file = e.target.files?.[0];
  if (file) importJSON(file);
  e.target.value = '';
});

amountVal.addEventListener('input', () => {
  if (!draft) return;
  const cleaned = sanitizeAmount(amountVal.value);
  if (cleaned !== amountVal.value) amountVal.value = cleaned;
  draft.amount = cleaned;
  saveEntry.disabled = !(Number(cleaned) > 0);
});

amountVal.addEventListener('focus', () => {
  if (!draft) return;
  // 聚焦时去掉千分位，方便直接改数字
  amountVal.value = draft.amount;
  requestAnimationFrame(() => {
    const len = amountVal.value.length;
    amountVal.setSelectionRange(len, len);
  });
});

amountVal.addEventListener('blur', () => {
  if (!draft) return;
  amountVal.value = draft.amount ? fmtRaw(draft.amount) : '';
});

document.addEventListener('keydown', (e) => {
  if (!activeSheet) return;
  if (e.key === 'Escape') {
    hideSheet();
  } else if (e.key === 'Enter') {
    e.preventDefault();
    if (activeSheet === 'entry') saveDraft();
    else if (activeSheet === 'deposit') saveDeposit();
    else if (activeSheet === 'goal') saveGoal();
  }
});

let resizeTimer;
window.addEventListener('resize', () => {
  clearTimeout(resizeTimer);
  resizeTimer = setTimeout(afterRender, 160);
});

window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', () => {
  if ((state.settings.theme || 'auto') === 'auto') {
    applyAppearance();
    afterRender();
  }
});

/* ========== 启动 ========== */
load();
ensureSavings();
applyAppearance();
render();

if ('serviceWorker' in navigator && location.protocol.startsWith('http')) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('sw.js').catch(() => {});

    // 新版本就绪时提示刷新
    navigator.serviceWorker.ready.then((reg) => {
      reg.addEventListener('updatefound', () => {
        const sw = reg.installing;
        if (!sw) return;
        sw.addEventListener('statechange', () => {
          if (sw.state === 'installed' && navigator.serviceWorker.controller) {
            const bar = $('#updateBar');
            bar.hidden = false;
            requestAnimationFrame(() => bar.classList.add('is-on'));
          }
        });
      });
    });
  });
}

$('#updateBtn').addEventListener('click', () => window.location.reload());
