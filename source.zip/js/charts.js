/* 轻量 Canvas 图表：不引入任何第三方图表库 */

function setup(canvas) {
  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  const w = canvas.clientWidth || 160;
  const h = canvas.clientHeight || 160;
  canvas.width = Math.round(w * dpr);
  canvas.height = Math.round(h * dpr);
  const ctx = canvas.getContext('2d');
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.clearRect(0, 0, w, h);
  return { ctx, w, h };
}

function cssVar(name, fallback) {
  const v = getComputedStyle(document.documentElement).getPropertyValue(name).trim();
  return v || fallback;
}

/**
 * 环形图
 * @param {HTMLCanvasElement} canvas
 * @param {{value:number,color:string}[]} items
 */
export function drawDonut(canvas, items) {
  if (!canvas) return;
  const { ctx, w, h } = setup(canvas);
  const total = items.reduce((s, i) => s + i.value, 0);
  const cx = w / 2;
  const cy = h / 2;
  const thickness = Math.max(14, Math.min(w, h) * 0.13);
  const r = Math.min(w, h) / 2 - thickness / 2 - 3;

  // 底环
  ctx.beginPath();
  ctx.strokeStyle = cssVar('--surface-2', '#f2f3f6');
  ctx.lineWidth = thickness;
  ctx.arc(cx, cy, r, 0, Math.PI * 2);
  ctx.stroke();

  if (!total) return;

  const multi = items.filter((i) => i.value > 0).length > 1;
  let start = -Math.PI / 2;

  for (const item of items) {
    if (item.value <= 0) continue;
    const angle = (item.value / total) * Math.PI * 2;
    if (angle <= 0.002) continue;
    // 间隙必须小于分段自身角度，否则 endAngle < startAngle 会绕整圈重绘
    const gap = multi ? Math.min(0.045, angle * 0.35) : 0;
    ctx.beginPath();
    ctx.strokeStyle = item.color;
    ctx.lineWidth = thickness;
    ctx.lineCap = 'round';
    ctx.arc(cx, cy, r, start + gap / 2, start + angle - gap / 2);
    ctx.stroke();
    start += angle;
  }
}

function roundRectTop(ctx, x, y, w, h, r) {
  const radius = Math.min(r, w / 2, Math.max(h, 0));
  ctx.beginPath();
  ctx.moveTo(x, y + h);
  ctx.lineTo(x, y + radius);
  ctx.quadraticCurveTo(x, y, x + radius, y);
  ctx.lineTo(x + w - radius, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + radius);
  ctx.lineTo(x + w, y + h);
  ctx.closePath();
}

/**
 * 柱状图
 * @param {HTMLCanvasElement} canvas
 * @param {{label:string,value:number}[]} items
 * @param {{activeIndex?:number}} opts
 */
export function drawBars(canvas, items, opts = {}) {
  if (!canvas) return;
  const { ctx, w, h } = setup(canvas);
  const activeIndex = opts.activeIndex ?? -1;
  const max = Math.max(...items.map((i) => i.value), 1);
  const labelH = 20;
  const chartH = Math.max(h - labelH, 20);
  const n = items.length || 1;
  const slot = w / n;
  const barW = Math.min(slot * 0.52, 26);
  const brand = cssVar('--brand', '#5b5bd6');
  const idle = cssVar('--bar', '#e6e8ee');
  const muted = cssVar('--text-3', '#9aa1ae');

  ctx.textAlign = 'center';
  ctx.font = '11px -apple-system, "PingFang SC", system-ui, sans-serif';

  items.forEach((item, i) => {
    const cx = slot * i + slot / 2;
    const isActive = i === activeIndex;
    const minH = item.value > 0 ? 5 : 3;
    const bh = Math.max((item.value / max) * (chartH - 8), minH);
    const x = cx - barW / 2;
    const y = chartH - bh;

    ctx.fillStyle = item.value > 0 ? (isActive ? brand : idle) : idle;
    roundRectTop(ctx, x, y, barW, bh, barW / 2);
    ctx.fill();

    if (isActive && item.value > 0) {
      ctx.globalAlpha = 0.16;
      ctx.fillStyle = brand;
      roundRectTop(ctx, x, y, barW, bh, barW / 2);
      ctx.fill();
      ctx.globalAlpha = 1;
    }

    ctx.fillStyle = isActive ? brand : muted;
    ctx.font = isActive
      ? '600 11px -apple-system, "PingFang SC", system-ui, sans-serif'
      : '11px -apple-system, "PingFang SC", system-ui, sans-serif';
    ctx.fillText(item.label, cx, h - 4);
  });
}
